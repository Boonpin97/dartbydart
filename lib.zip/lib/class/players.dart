class Players {
  String name;
  int current_score = 301;
  int highest_score = 0;
  int avg_score = 0;

  Players(this.name);
}